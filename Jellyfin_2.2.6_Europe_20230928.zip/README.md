# SamsungSmartTV

Warning: This app is a legacy program meant for older Samsung Smart TVs running Orsay (pre-2015), which has since been replaced by Tizen. It may be possible to use this app by side-loading, but it is considered unsupported (we are unable to help you with it).

You may also wish to try a web browser with Jellyfin, wherever possible.
